﻿#Andrea Paola Arzate Rodriguez

$inicio = Read-Host -Promp 'Desea ir al menu? [Si][No]'

while ($inicio -eq "Si")
{
$opc = Read-Host -Prompt '[1]Ver StatusPerfil 
[2]Cambiar StatusPerfil 
[3]Ver PerfilActual 
[4]Cambiar Perfil RedActual 
[5]Ver ReglasBloqueo 
[6]Agregar ReglasBloqueo 
[7]Eliminar ReglasBloqueo
[8]Salir

¿QUÉ OPCIÓN DESEA ELEGIR?'

switch($opc){ 
    1 {
        Ver-StatusPerfil
    }
    2 {
        Cambiar-StatusPerfil 
    }
    3 {
        Ver-PerfilRedActual
    }
    4 {
        Cambiar-PerfilRedActual
    }
    5 {
        Ver-ReglasBloqueo
    }
    6 {
        Agregar-ReglasBloqueo
    }
    7 {
        Eliminar-ReglasBloqueo
    }
    8 {
        Write-Host 'Usted a decidido salirse del menu principal.
        Hasta Luego:)'
        exit 
    }
    default {
        Write-Host 'Opción no valida, escriba un número del menu.'
    }
}
}
    if ($inicio -eq "No"){
        Write-Host '    Hasta Luego:)'
        exit
    }
    
 

